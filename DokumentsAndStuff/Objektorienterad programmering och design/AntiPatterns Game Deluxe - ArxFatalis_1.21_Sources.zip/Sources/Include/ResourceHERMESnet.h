//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinMain.rc
//
#define IDD_MUTLIPLAYER_CONNECT         101
#define IDD_MUTLIPLAYER_GAMES           102
#define IDC_RETURN                      102
#define IDD_MAIN_GAME                   103
#define IDD_MULTIPLAYER_CREATE          104
#define IDI_MAIN                        106
#define IDD_LOBBY_WAIT_STATUS           114
#define IDC_PLAYER_NAME_EDIT            1000
#define IDC_GAMES_LIST                  1001
#define IDC_JOIN                        1002
#define IDC_CREATE                      1003
#define IDC_CONNECTION_LIST             1004
#define IDC_BACK                        1005
#define IDC_CHECK_DPLAY_PROTOCOL        1006
#define IDC_EDIT_SESSION_NAME           1007
#define IDC_CHAT_EDIT                   1010
#define IDC_CHAT_LISTBOX                1012
#define IDC_SEARCH_CHECK                1013
#define IDC_LOBBYCONNECTCANCEL          1029
#define IDC_NUM_PLAYERS                 1030
#define IDC_SEND                        1034
#define IDC_WAIT_TEXT                   1035

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
