#pragma once
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

//#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers


#include "CU/Includes/CUCommonIncludes.h"
#include "CU/NameSpaceAliases.h"
#include "CU/Containers/GrowingArray/GrowingArray.h"
#include <iostream>
#include <fstream>
#include <CU/Utility/CommonCasts.h>
#include "CU/Macros/Macros.h"
// TODO: reference additional headers your program requires here