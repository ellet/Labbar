#pragma once

struct BaseObjectData
{};