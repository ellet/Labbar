#pragma once

namespace CommonUtilities
{

	class BaseCreationManager
	{
	public:
		BaseCreationManager()
		{
		}
		virtual ~BaseCreationManager()
		{
		}
	};

}