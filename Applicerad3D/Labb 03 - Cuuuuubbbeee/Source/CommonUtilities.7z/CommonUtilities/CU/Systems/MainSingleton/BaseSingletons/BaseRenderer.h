#pragma once

namespace CommonUtilities
{

	class BaseRenderer
	{
	public:
		BaseRenderer()
		{
		}
		virtual ~BaseRenderer()
		{
		}
	};

}