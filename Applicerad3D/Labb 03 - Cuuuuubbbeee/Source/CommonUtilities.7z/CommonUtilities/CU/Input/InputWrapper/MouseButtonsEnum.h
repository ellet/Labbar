#pragma once

namespace CommonUtilities
{
	enum class enumMouseButtons
	{
		eLeft,
		eRight,
		eMiddle,
		enumLength
	};
}