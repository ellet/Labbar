#pragma once

#include <math.h>
#include <cmath>
#include <assert.h>
#include <iostream>
#include <sstream>
#include <unordered_map>