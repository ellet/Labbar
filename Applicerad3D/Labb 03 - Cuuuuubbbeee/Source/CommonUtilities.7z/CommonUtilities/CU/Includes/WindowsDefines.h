#pragma once


typedef long LONG;

typedef __int64 LONGLONG;

typedef unsigned long DWORD;