#include "stdafx.h"
#include "LineSegment3D.h"

namespace Intersection3D
{


	LineSegment3D::LineSegment3D()
	{
	}


	LineSegment3D::~LineSegment3D()
	{
	}

};