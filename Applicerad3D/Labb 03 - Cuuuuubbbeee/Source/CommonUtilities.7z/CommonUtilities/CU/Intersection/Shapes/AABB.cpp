#include "stdafx.h"
#include "AABB.h"



namespace Intersection3D
{

	AABB::AABB()
	{
	}


	AABB::~AABB()
	{
	}

};