#include "stdafx.h"
#include "Sphere.h"

namespace Intersection3D
{


	Sphere::Sphere()
	{
	}


	Sphere::~Sphere()
	{
	}

};