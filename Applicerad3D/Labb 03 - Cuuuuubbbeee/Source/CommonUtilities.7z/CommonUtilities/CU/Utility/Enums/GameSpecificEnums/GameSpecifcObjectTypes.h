#pragma once

enum class GameObjectTypes
{
	eAsteroid,
	ePlayer,
	enumlength
};