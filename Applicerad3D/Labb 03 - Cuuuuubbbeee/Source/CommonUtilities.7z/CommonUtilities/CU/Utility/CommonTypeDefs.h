#pragma once

typedef CU::Vector2ui PixelPosition;
typedef CU::Vector2f PixelPositionFloat;
typedef CU::Vector2f NormalizedPosition;
typedef CU::Vector2f VectorDirection;
typedef CU::Vector2f NormalizedDirection;