#pragma once

#define FLOATCAST(variable) static_cast<float>((variable))



#define USHORTCAST(variable) static_cast<unsigned short>((variable))

#define INTCAST(variable) static_cast<int>((variable))
#define SIZE_TTCAST(variable) static_cast<size_t>((variable))