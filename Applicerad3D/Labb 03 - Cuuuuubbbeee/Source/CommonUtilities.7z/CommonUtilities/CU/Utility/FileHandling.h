#pragma once
#include <string>

namespace CommonUtilities
{
	std::string GetFileAsString(const std::string & aFilePath);
}