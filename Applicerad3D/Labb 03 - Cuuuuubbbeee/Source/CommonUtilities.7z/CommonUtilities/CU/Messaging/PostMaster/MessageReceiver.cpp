#include "stdafx.h"
#include "MessageReceiver.h"

bool MessageReceiver::ReceiveMessage(const BaseMessage & aMessage)
{
	(aMessage);
	return true;
}
