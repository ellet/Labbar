#pragma once

enum class ReceiverOrder
{
	VIP,
	eGUI,
	eDefault = 100,
	enumLength
};

enum class ReceiverTypes
{
	eWindowProperties,
	ePlayer,
	enumlength
};