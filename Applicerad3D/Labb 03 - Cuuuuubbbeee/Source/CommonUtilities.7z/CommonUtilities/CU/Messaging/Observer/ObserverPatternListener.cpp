#include "stdafx.h"
#include "ObserverPatternListener.h"


ObserverPatternListener::ObserverPatternListener()
{
}


ObserverPatternListener::~ObserverPatternListener()
{
}