#include "stdafx.h"
#include "GraphicalContent.h"


GraphicalContent::~GraphicalContent()
{
}
