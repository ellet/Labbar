#include "BaseShape.h"

namespace Intersection3D
{

	BaseShape::BaseShape()
	{
	}


	BaseShape::~BaseShape()
	{
	}
};