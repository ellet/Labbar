#include "ObserverPatternListener.h"


ObserverPatternListener::ObserverPatternListener()
{
}


ObserverPatternListener::~ObserverPatternListener()
{
}
