#pragma once
namespace CommonUtilities{};

namespace CU = CommonUtilities;